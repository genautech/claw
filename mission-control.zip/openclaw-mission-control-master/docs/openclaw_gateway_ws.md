# Gateway WebSocket protocol

Placeholder.
